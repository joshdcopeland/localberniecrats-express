npm install -g nodemon

nodemon src/app.js

http://localhost:3000/